# Deniz 🤍 — Sevgi saytı

GitHub Pages üçün hazır, mobil uyğun animasiyalı sevgi saytı.

## GitHub-a yerləşdirmək
1. ZIP-i aç.
2. GitHub-da yeni repository yarat.
3. `index.html` və `README.md` fayllarını repository-yə yüklə.
4. **Settings → Pages** bölməsinə keç.
5. **Deploy from a branch** seç, `main` və `/ (root)` seçib **Save** bas.
6. Sayt linki Pages bölməsində görünəcək.

## Mahnı
Saytdakı **Mahnı seç** düyməsi cihazdan audio fayl seçib həmin brauzerdə səsləndirir. Fayl internetə yüklənmir. Mahnının sayta hamı üçün daxil olmasını istəyirsənsə, audio faylını repository-yə ayrıca əlavə edib HTML-də ona bağlamaq lazımdır. Yalnız istifadə etmək hüququn olan audio fayllarını yerləşdir.
